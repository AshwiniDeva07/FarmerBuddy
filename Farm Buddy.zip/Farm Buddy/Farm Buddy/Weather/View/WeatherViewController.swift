//
//  WeatherViewController.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 02/02/24.
//

import UIKit
import CoreLocation
import Alamofire



class WeatherViewController: UIViewController,CLLocationManagerDelegate  {
    
    
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var weatherTypeLabel: UILabel!
    @IBOutlet weak var weatherDetailView: UIView!
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var pressureLabel: UILabel!
    @IBOutlet weak var hourlyCollectionView: UICollectionView!
    @IBOutlet weak var dailyTableView: UITableView!
    @IBOutlet weak var currentImageView: UIImageView!
    @IBOutlet weak var feelsLikeLabel: UILabel!
    @IBOutlet weak var sunRiseLabel: UILabel!
    @IBOutlet weak var sunSetLabel: UILabel!
    
    
    var hourlyWeather: [Current] = []
    var dailyWeather: [Daily] = []
    let weatherViewModel = WeatherViewModel()
    var locationNil = 0
    private var locationManager = CLLocationManager()
    
    
    var tempView: UIView = {
        let view = UIView()
        view.tag = 100
        view.backgroundColor = #colorLiteral(red: 0.1058823529, green: 0.1137254902, blue: 0.1215686275, alpha: 1)
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        hourlyCollectionView.delegate = self
        hourlyCollectionView.dataSource = self
        
        dailyTableView.delegate = self
        dailyTableView.dataSource = self
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        
        fetchLocationData()
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if locationNil == 1{
            fetchLocationData()
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            // Handle authorized status
            print("Location permission granted")
            fetchLocationData()

        case .denied, .restricted:
            // Handle denied or restricted status
            print("Location permission denied or restricted")
            
        case .notDetermined:
            // Handle not determined status (e.g., ask for permission)
            print("Location permission not determined")
            
        @unknown default:
            break
        }
    }
    
    //MARK:- Function to fetch user's location data
    func fetchLocationData() {
        weatherViewModel.fetchWeather { location in
            if location != nil{
                CLGeocoder().reverseGeocodeLocation(location ?? CLLocation()) { [self] (placemarks, error) -> Void in
                    if error != nil {
                        return
                    }else if let country = placemarks?.first?.country,
                             let city = placemarks?.first?.locality {
                        cityLabel.text = "\(city), \(country)"
                    }
                }
                let url = "https://api.openweathermap.org/data/3.0/onecall?lat=\(location?.coordinate.latitude ?? 0.0)&lon=\(location?.coordinate.longitude ?? 0.0)&appid=\(AppInstance.key)"
                print("URL=", url)
                self.fetchWeatherData(weatherAPIURL: url)
            }else{
                
                self.locationDenied()
            }
        }
    }
    
    //MARK:- Function to fetch weather data
    func fetchWeatherData(weatherAPIURL: String) {
        
        weatherViewModel.fetchWeatherInfo(url: weatherAPIURL) { result in
            switch result {
            case .success(let weatherModel):
                // Handle success, weatherModel contains the parsed data
                if let weatherModel = weatherModel {
                    
                    if let tempView = self.view.viewWithTag(100) {
                        UIView.animate(withDuration: 1.0, delay: 0.0, options: UIView.AnimationOptions.curveEaseInOut, animations: { () -> Void in
                            tempView.alpha = 0
                        }) { completed in
                            tempView.removeFromSuperview()
                        }
                    }
                    
                    let currentConditions = weatherModel.current
                    let weather = currentConditions?.weather
                    let hourly = weatherModel.hourly
                    let daily = weatherModel.daily
                    
                    DispatchQueue.main.async {
                        self.updateUI(with: currentConditions ?? Current(), weather: weather ?? [Weather](), hourly: hourly ?? [Current](), daily: daily ?? [Daily]())
                    }
                    
                } else {
                    print("Weather model is nil.")
                }
                
            case .failure(let error):
                // Handle failure
                print("Error fetching weather: \(error)")
            }
        }
        
    }
    
    //MARK:- Updating data in UI
    func updateUI(with currentConditions: Current, weather: [Weather], hourly: [Current], daily: [Daily]) {
        
        temperatureLabel.text = "\(String(format: "%.0f", (currentConditions.temp ?? 0) - 273.15))°"
        weatherTypeLabel.text = "\(weather.first?.description ?? "")".capitalized
        //        currentImageView.image = AppInstance.shared.imageForCurrentWeather(weather: "\(weather.first?.description ?? "")")
        
        feelsLikeLabel.text = "Feels like \(String(format: "%.1f", (currentConditions.feelsLike ?? 0) - 273.15))°"
        sunRiseLabel.text = "Sunrise \(AppInstance.shared.epochToLocalTime(epochTime: currentConditions.sunrise ?? 0, dateRequired: false))"
        sunSetLabel.text = "Sunset \(AppInstance.shared.epochToLocalTime(epochTime: currentConditions.sunset ?? 0, dateRequired: false))"
        windLabel.text = "\(currentConditions.windSpeed ?? 0) m/s"
        humidityLabel.text = "\(currentConditions.humidity ?? 0) %"
        pressureLabel.text = "\(currentConditions.pressure ?? 0) hPa"
        
        hourlyWeather = hourly
        dailyWeather = daily
        
        hourlyCollectionView.reloadData()
        dailyTableView.reloadData()
        
    }
    
    //MARK:- Function to get location access from user
    func locationDenied(){
        
        view.addSubview(tempView)
        tempView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
        view.bringSubviewToFront(tempView)
        
        let label = UILabel()
        label.text = "Location Denied"
        label.textAlignment = .center
        label.textColor = .white
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.translatesAutoresizingMaskIntoConstraints = false
        
        let button = UIButton(type: .system)
        button.setTitle("Open Settings", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .white
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(openSettings), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        
        tempView.addSubview(label)
        tempView.addSubview(button)
        
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor),
        ])
        
        NSLayoutConstraint.activate([
            button.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 20),
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button.widthAnchor.constraint(equalToConstant: 200), 
            button.heightAnchor.constraint(equalToConstant: 40)
        ])
        
    }
    
    @objc func openSettings() {
        // Open settings when the button is tapped
        if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
            self.locationNil = 1
            UIApplication.shared.open(settingsURL, options: [:], completionHandler: nil)
        }
    }
    
    
}

extension WeatherViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dailyWeather.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let currentData = dailyWeather[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "DailyTableViewCell", for: indexPath) as! DailyTableViewCell
        cell.separatorInset = .zero
        cell.selectionStyle = .none
        cell.dayLabel.text = AppInstance.shared.epochToLocalTime(epochTime: currentData.dt ?? 0, dateRequired: true)
        let temperatureData = currentData.temp
        
        let lowTemp = String(format: "%.0f", (((temperatureData?.min ?? 0) - 273.15)))
        let highTemp = String(format: "%.0f", ((temperatureData?.max ?? 0) - 273.15))
        cell.temperatureLabel.text = "Low \(lowTemp)°     High \(highTemp)°"
        let weather = currentData.weather
        cell.weatherImageView.image = AppInstance.shared.imageForCurrentWeather(weather: "\(weather?.first?.main ?? "")")
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if UIDevice.current.userInterfaceIdiom == .pad {
            return 70
        } else {
            return 60
        }
    }
}

extension WeatherViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return hourlyWeather.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let currentData = hourlyWeather[indexPath.row]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HourlyCollectionViewCell", for: indexPath) as! HourlyCollectionViewCell
        cell.timeLabel.text = AppInstance.shared.epochToLocalTime(epochTime: currentData.dt ?? 0, dateRequired: false)
        cell.temperatureLabel.text = "\(String(format: "%.0f", ((currentData.temp ?? 0.0) - 273.15)))°"
        let weather = currentData.weather?[0].main as? String
        cell.weatherImageView.image = AppInstance.shared.imageForCurrentWeather(weather: weather ?? "")
        return cell
    }
}
extension WeatherViewController {
    
    func setupUI() {

        weatherDetailView.layer.cornerRadius = 15
        
        
        dateLabel.text = AppInstance.shared.getLocalDate()
        
        // Register collection view and table view cells
        hourlyCollectionView.register(UINib(nibName: "HourlyCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HourlyCollectionViewCell")
        dailyTableView.register(UINib(nibName: "DailyTableViewCell", bundle: nil), forCellReuseIdentifier: "DailyTableViewCell")
        
        // configure layout for collection view cells
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 10, left: 15, bottom: 10, right: 15)
        layout.itemSize = CGSize(width: 120, height: 120)
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        hourlyCollectionView.collectionViewLayout = layout
    }
}
