//
//  WeatherViewModel.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 03/02/24.
//

import Foundation
import CoreLocation
import Alamofire

class WeatherViewModel {
    
    private var locationManager = LocationManager()
    private let key = "d4d20ef76e6d8db277d54c5a66a4db38"
    
    typealias WeatherCompletion = (Result<WeatherData?, Error>) -> Void
        
    // Function to fetch location and call API
    func fetchWeather(completion: @escaping (CLLocation?) -> Void) {
        locationManager.getCurrentLocation { location in
            completion(location)
        }
    }
    //MARK:- Weather data API call
    func fetchWeatherInfo(url: String, completion: @escaping WeatherCompletion) {
        AF.request(url).responseDecodable(of: WeatherData.self) { response in
            switch response.result {
            case .success(let weatherModel):
                completion(.success(weatherModel))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
