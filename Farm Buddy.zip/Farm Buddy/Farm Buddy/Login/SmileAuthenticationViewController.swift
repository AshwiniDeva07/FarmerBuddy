//
//  ViewController.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 31/01/24.
//

import UIKit
import ARKit

class SmileAuthenticationViewController: UIViewController , ARSCNViewDelegate {
    
    var sceneView: ARSCNView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        sceneView = ARSCNView()
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sceneView)
        
        NSLayoutConstraint.activate([
            sceneView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            sceneView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            sceneView.widthAnchor.constraint(equalToConstant: 300),
            sceneView.heightAnchor.constraint(equalToConstant: 300)
        ])
        
        sceneView.delegate = self
        
        let scene = SCNScene()
        
        sceneView.scene = scene
        //MARK:- Enable face tracking
        guard ARFaceTrackingConfiguration.isSupported else {
            displayErrorAlert(message: "Face tracking is not supported on this device.")
            return
        }
        
        
        let configuration = ARFaceTrackingConfiguration()
        sceneView.session.run(configuration)
    }
    
    func displayErrorAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    //MARK:- AR ViewDelegate method to update the scene
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceAnchor = anchor as? ARFaceAnchor else { return }
        
        //MARK:- Access facial expression data
        let isSmiling = faceAnchor.blendShapes[.mouthSmileLeft] as? Float ?? 0.0
        
        if isSmiling > 0.5 {
            DispatchQueue.main.async {
                self.unlockApp()
            }
        }
    }
    
    //MARK:- Unlock the app
    func unlockApp() {
        print("App unlocked!")
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "IntroViewController") as? IntroViewController
        self.navigationController?.pushViewController(vc!, animated: false)
    }
}

