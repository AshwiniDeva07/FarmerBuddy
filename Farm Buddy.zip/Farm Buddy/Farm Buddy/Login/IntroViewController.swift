//
//  IntroViewController.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 31/01/24.
//

import UIKit

class IntroViewController: UIViewController, UIScrollViewDelegate {
    
    let images = ["intro1", "intro2", "intro3"]
    var descriptions: [String] = ["Farmers use weather predictions to make informed decisions about their agricultural practices.", "In the unfortunate event of agricultural losses caused by natural calamities, farmers may seek donations to aid in recovering from the financial hardships and rebuilding their livelihoods.", "Through a centralized list on a dedicated app, users can donate to farmers in need, fostering a community-driven initiative to support and uplift those facing agricultural challenges."]
    
    
    let scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.isPagingEnabled = true
        scrollView.backgroundColor = .white
        return scrollView
    }()
    
    let pageControl: UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.currentPageIndicatorTintColor = .black
        pageControl.pageIndicatorTintColor = .gray
        return pageControl
    }()
    
    let skipButton: UIButton = {
        let button = UIButton()
        button.setTitle("Skip", for: .normal)
        button.setTitleColor(.blue, for: .normal)
        return button
    }()
    
    let nextButton: UIButton = {
        let button = UIButton()
        button.setTitle("Next", for: .normal)
        button.setTitleColor(.blue, for: .normal)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        setupScrollView()
        setupPageControl()
        setupButtons()
        setupImageDescriptions()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //scrollView.delegate = self
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        scrollView.delegate = self
    }
    
    //MARK:- Scroll view functionality
    func setupScrollView() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.backgroundColor = .clear
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        for (index, imageName) in images.enumerated() {
            let imageView = UIImageView(image: UIImage(named: imageName))
            imageView.contentMode = .scaleToFill
            imageView.layer.cornerRadius = 20
            imageView.frame = CGRect(x: CGFloat(index) * view.frame.width + 25,
                                     y: 120,
                                     width: view.frame.width - 50,
                                     height: 300)
            scrollView.addSubview(imageView)
        }
        
        scrollView.contentSize = CGSize(width: CGFloat(images.count) * view.frame.width, height: view.frame.height)
    }
    
    //MARK:- pagination
    func setupPageControl() {
        view.addSubview(pageControl)
        pageControl.numberOfPages = images.count
        pageControl.currentPage = 0
        pageControl.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            pageControl.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            pageControl.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func setupButtons() {
        skipButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(skipButton)
        skipButton.addTarget(self, action: #selector(skipButtonTapped), for: .touchUpInside)
        
        
        nextButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nextButton)
        nextButton.addTarget(self, action: #selector(nextButtonTapped), for: .touchUpInside)
        
        
        NSLayoutConstraint.activate([
            skipButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 20),
            skipButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            
            nextButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 20),
            nextButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
        ])
    }
    
    //MARK:- image description setup
    func setupImageDescriptions() {
        for i in 0..<scrollView.subviews.count {
            let imageView = scrollView.subviews[i] as! UIImageView
            
            let descriptionLabel = UILabel()
            descriptionLabel.text = descriptions[i]
            descriptionLabel.textColor = .black
            descriptionLabel.textAlignment = .center
            descriptionLabel.numberOfLines = 0
            descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
            
            imageView.addSubview(descriptionLabel)
            
            NSLayoutConstraint.activate([
                descriptionLabel.leadingAnchor.constraint(equalTo: imageView.leadingAnchor, constant: 16),
                descriptionLabel.trailingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: -16),
                descriptionLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
                descriptionLabel.bottomAnchor.constraint(equalTo: pageControl.bottomAnchor, constant: -50)
            ])
        }
    }
    
    // MARK: - UIScrollViewDelegate
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageWidth = scrollView.frame.width
        let currentPage = Int(floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1)
        pageControl.currentPage = currentPage
        
        
        
        let offset = scrollView.contentOffset.x - CGFloat(currentPage) * pageWidth
        let absoluteOffset = abs(offset)
        let maximumOffset = pageWidth
        
        // Apply scaling and translation animation to the image view
        let scale = max(0.5, 1 - (absoluteOffset / maximumOffset))
        let translation = max(0, min(100, offset))
        
        for i in 0..<scrollView.subviews.count {
            if let imageView = scrollView.subviews[i] as? UIImageView {
                let transform = CGAffineTransform(scaleX: scale, y: scale).translatedBy(x: 0, y: translation)
                imageView.transform = transform
            }
        }
    }
    
    //MARK:- navigation
    @objc func skipButtonTapped() {
        //login
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "TabBarViewController") as? TabBarViewController
        vc?.selectedIndex = 0
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @objc func nextButtonTapped() {
        if pageControl.currentPage < images.count - 1 {
            let nextPage = min(pageControl.currentPage + 1, scrollView.subviews.count - 1)
            scrollToPage(page: nextPage, animated: true)
        }else{
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "TabBarViewController") as? TabBarViewController
            vc?.selectedIndex = 0
            self.navigationController?.pushViewController(vc!, animated: true)
        }
    }
    
    //MARK:- Helper function to scroll to a specific page
    
    func scrollToPage(page: Int, animated: Bool) {
        let xOffset = CGFloat(page) * scrollView.frame.width
        scrollView.setContentOffset(CGPoint(x: xOffset, y: 0), animated: animated)
    }
}
