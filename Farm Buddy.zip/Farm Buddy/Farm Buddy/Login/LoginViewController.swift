//
//  LoginViewController.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 31/01/24.
//

import UIKit
import Security

class LoginViewController: UIViewController {
    
    @IBOutlet weak var logoImg: UIImageView!
    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var mobileNumberTextfield: UITextField!
    
    @IBOutlet weak var loginBtn: GradientButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        userNameTextfield.placeholder = "Enter Name"
        userNameTextfield.textColor = UIColor.black
        userNameTextfield.backgroundColor = .white
        userNameTextfield.layer.cornerRadius = 8
        
        mobileNumberTextfield.placeholder = "Enter Mobile number"
        mobileNumberTextfield.textColor = UIColor.black
        mobileNumberTextfield.backgroundColor = .white
        mobileNumberTextfield.layer.cornerRadius = 8
        mobileNumberTextfield.keyboardType = .numberPad
        
        addDoneButtonToNumericKeyboard()
        
        logoImg.layer.cornerRadius = logoImg.frame.width/2
        updateLoginButtonState()
    }
    
    override func viewDidLayoutSubviews() {
        loginBtn.setGradientColor(colors: [AppColors.PrimarylogoColor.cgColor,AppColors.PrimaryyellowColor.cgColor])

    }
    
    // MARK: - Numeric Keyboard with Done Button
    
    func addDoneButtonToNumericKeyboard() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.items = [UIBarButtonItem.flexibleSpace(), doneButton]
        
        mobileNumberTextfield.inputAccessoryView = toolbar
    }
    
    @objc func doneButtonTapped() {
        view.endEditing(true)
        mobileNumberTextfield.resignFirstResponder()
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    @IBAction func LoginButtonTapped(_ sender: UIButton) {
        
        AppInstance.shared.saveLogStatus(isLoggedin: true)
        
        navigateToLogin()
        
    }
    
    
    //MARK:- navigation
    func navigateToLogin() {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "SmileAuthenticationViewController") as? SmileAuthenticationViewController
        self.navigationController?.pushViewController(vc!, animated: false)
    }
    
    //MARK:- Logib button state update
    func updateLoginButtonState() {
        let isUsernameValid = isUsernameValid()
        let isMobileNumberValid = isMobileNumberValid()
        
        // Enable the login button only if both username and mobile number are valid
        loginBtn.isEnabled = isUsernameValid && isMobileNumberValid
    }
    
    //MARK:- User name validation
    func isUsernameValid() -> Bool {
        guard let username = userNameTextfield.text else {
            return false
        }
        
        // Ensure at least 2 alpha characters are present
        let alphaCount = username.filter { $0.isLetter }.count
        return alphaCount >= 2 && username.count <= 25
    }
    
    //MARK:- Mobile number validation
    func isMobileNumberValid() -> Bool {
        guard let mobileNumber = mobileNumberTextfield.text else {
            return false
        }
        
        // Ensure mobile number is numeric and has a length of 10
        return mobileNumber.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil && mobileNumber.count == 10
    }
    
}

extension LoginViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        updateLoginButtonState()
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == userNameTextfield {
            let currentText = textField.text ?? ""
            let newText = (currentText as NSString).replacingCharacters(in: range, with: string)
            return newText.count <= 25
        } else if textField == mobileNumberTextfield {
            let currentText = textField.text ?? ""
            let newText = (currentText as NSString).replacingCharacters(in: range, with: string)
            return newText.count <= 10
        }
        return true
    }
    
    
}
