//
//  Common+Extension.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 02/02/24.
//

import Foundation
import UIKit

struct AppColors {
    static let lightBlueColor = UIColor(red: 0.0/255.0, green: 123.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    static let lightOrangeColor = UIColor(red: 255.0/255.0, green: 149.0/255.0, blue: 0.0/255.0, alpha: 1.0)
    static let lightGoldColor = UIColor(red: 1.0, green: 0.84, blue: 0.0, alpha: 1.0).cgColor
    static let darkGoldColor =  UIColor(red: 0.96, green: 0.73, blue: 0.0, alpha: 1.0).cgColor
    
    static let PrimarylogoColor = UIColor(hexString: "#EBDCCF")
    static let PrimaryWhiteColor = UIColor(hexString: "#FFFFFF")
    static let PrimaryyellowColor =  UIColor(hexString: "#EBB605")
    static let PrimaryGreenColor = UIColor(hexString: "#002200")
}


class AppInstance {
    
    static let shared = AppInstance()
    
    private init(){
        
    }
    
    // API key
    public static let key: String = "d4d20ef76e6d8db277d54c5a66a4db38"
    
    
    // Example: Saving user data to UserDefaults
    func saveLogStatus(isLoggedin: Bool) {
            UserDefaults.standard.set(isLoggedin, forKey: "isLoggedin")
            UserDefaults.standard.synchronize()
        }
    
    
    // Get local Date string
    func getLocalDate() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE, d MMMM"
        return dateFormatter.string(from: Date().localDate())
    }
    
    // Retrieve Local time from UNIX time
    func epochToLocalTime(epochTime: Int, dateRequired: Bool) -> String {
        let currentTime = Double(epochTime)
        let date = Date(timeIntervalSince1970: currentTime)
        let dateFormatter = DateFormatter()
        if dateRequired {
            dateFormatter.dateFormat = "EEEE"
        } else {
            dateFormatter.timeStyle = DateFormatter.Style.short
        }
        return dateFormatter.string(from: date)
    }
    
    // Images for current weather condition
    func imageForCurrentWeather(weather: String) -> UIImage {
        switch weather {
        case "Thunderstorm":
            return UIImage(named: "thunderstorm")!
        case "Drizzle":
            return UIImage(named: "drizzle")!
        case "Rain":
            return UIImage(named: "rain")!
        case "Snow":
            return UIImage(named: "snowflakes")!
        case "Atmosphere":
            return UIImage(named: "haze")!
        case "Mist":
            return UIImage(named: "haze")!
        case "Haze":
            return UIImage(named: "haze")!
        case "Smoke":
            return UIImage(named: "haze")!
        case "Dust":
            return UIImage(named: "haze")!
        case "Fog":
            return UIImage(named: "haze")!
        case "Sand":
            return UIImage(named: "haze")!
        case "Ash":
            return UIImage(named: "haze")!
        case "Squall":
            return UIImage(named: "haze")!
        case "Tornado":
            return UIImage(named: "haze")!
        case "Clear":
            return UIImage(named: "clear")!
        case "Clouds":
            return UIImage(named: "clouds")!
        default:
            return UIImage()
        }
    }
    
}

extension UILabel{
    func customizeLabel(text: String?, font: UIFont, textColor: UIColor, align: NSTextAlignment = .left, fontSize: CGFloat = 10){
        self.text = text
        self.textColor = textColor
        self.font = font.withSize(fontSize)
        self.textAlignment = align
        
    }
    func applyStyleLbl(cornerRadius: CGFloat, borderColor: UIColor?, borderWidth: CGFloat) {
        layer.cornerRadius = cornerRadius
        layer.masksToBounds = true
        
        if let color = borderColor {
            layer.borderColor = color.cgColor
            layer.borderWidth = borderWidth
        }
        
        
    }
    
    func applyShadowLbl(shadowColor: UIColor?, shadowOffset: CGSize, shadowOpacity: Float){
        if let shadowClr = shadowColor {
            layer.shadowColor = shadowClr.cgColor
            layer.shadowOffset = shadowOffset
            layer.shadowOpacity = shadowOpacity
            layer.shadowRadius = 0.0 // Adjust as needed
            layer.shouldRasterize = true
            layer.rasterizationScale = UIScreen.main.scale
        }
    }
    
}

extension UIButton{
    func customizeButton(text: String?, font: UIFont, textColor: UIColor, align: NSTextAlignment = .left, fontSize: CGFloat = 10, bgColor: UIColor?){
        self.setTitle(text, for: .normal)
        self.setTitleColor(textColor, for: .normal)
        self.titleLabel?.font = font.withSize(fontSize)
        self.titleLabel?.textAlignment = align
        self.backgroundColor = bgColor
    }
    func applyStyleBtn(cornerRadius: CGFloat, borderColor: UIColor?, borderWidth: CGFloat) {
        layer.cornerRadius = cornerRadius
        layer.masksToBounds = true
        
        if let color = borderColor {
            layer.borderColor = color.cgColor
            layer.borderWidth = borderWidth
        }
        
        
    }
    
    func applyShadowBtn(shadowColor: UIColor?, shadowOffset: CGSize, shadowOpacity: Float){
        if let shadowClr = shadowColor {
            layer.shadowColor = shadowClr.cgColor
            layer.shadowOffset = shadowOffset
            layer.shadowOpacity = shadowOpacity
            layer.shadowRadius = 0.0 // Adjust as needed
            layer.shouldRasterize = true
            layer.rasterizationScale = UIScreen.main.scale
        }
    }
    
    func setGradientColor(colors: [CGColor]?) {
        // Remove existing gradient layers
        removeGradientLayers()
        
        // Set gradient colors
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = self.bounds
        gradientLayer.colors = colors  // Customize gradient colors
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 0.7, y: 0.5)
        
        // Apply gradient to button layer
        self.layer.insertSublayer(gradientLayer, at: 0)
        self.layer.masksToBounds = true
    }
    
    func removeGradientLayers() {
        // Remove existing gradient layers
        if let sublayers = self.layer.sublayers {
            for layer in sublayers {
                if layer is CAGradientLayer {
                    layer.removeFromSuperlayer()
                }
            }
        }
    }
    
}

extension UIColor {
    /**
     Creates an UIColor from HEX String in "#363636" format
     - parameter hexString: HEX String in "#363636" format
     - returns: UIColor from HexString
     */
    
    
    convenience init(hexString: String) {
        
        let hexString: String = (hexString as NSString).trimmingCharacters(in: .whitespacesAndNewlines)
        let scanner          = Scanner(string: hexString as String)
        
        if hexString.hasPrefix("#") {
            scanner.scanLocation = 1
        }
        
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        
        self.init(red:red, green:green, blue:blue, alpha:1)
    }
}

extension Date {
    func localDate() -> Date {
        let nowUTC = Date()
        let timeZoneOffset = Double(TimeZone.current.secondsFromGMT(for: nowUTC))
        guard let localDate = Calendar.current.date(byAdding: .second, value: Int(timeZoneOffset), to: nowUTC) else {return Date()}
        return localDate
    }
}


