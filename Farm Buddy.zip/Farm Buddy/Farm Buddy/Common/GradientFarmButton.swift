//
//  GradientFarmButton.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 02/02/24.
//

import Foundation
import UIKit

@IBDesignable
class GradientButton: UIButton {
    
    @IBInspectable
    var startColor: UIColor = UIColor.yellow {
        didSet {
            setNeedsDisplay()
        }
    }
    
    @IBInspectable
    var endColor: UIColor = UIColor.green {
        didSet {
            setNeedsDisplay()
        }
    }
    
    @IBInspectable
    var cornerRadius: CGFloat = 8.0 {
        didSet {
            layer.cornerRadius = cornerRadius
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        layer.cornerRadius = cornerRadius
        clipsToBounds = true
    }
    
    override func draw(_ rect: CGRect) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        gradientLayer.colors = [startColor.cgColor, endColor.cgColor]
        gradientLayer.cornerRadius = cornerRadius
        
        UIGraphicsBeginImageContextWithOptions(bounds.size, false, 0.0)
        gradientLayer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        setBackgroundImage(image, for: .normal)
    }
    
    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()
        commonInit()
        draw(bounds)
    }
}
