//
//  CoreLocation.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 03/02/24.
//

import Foundation
import CoreLocation


class LocationManager: NSObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()
    
    //MARK:- Get user current location
    func getCurrentLocation(completion: @escaping (CLLocation?) -> Void){
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        
        checkLocationAuthorizationStatus  { status in
            switch status {
            case .authorizedWhenInUse, .authorizedAlways:
                print("Location services are authorized.")
                self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
                self.locationManager.startUpdatingLocation()
                
                // Get the current location
                if let location = self.locationManager.location {
                    completion(location)
                    
                } else {
                    print("Unable to get current location.")
                    self.locationManager.requestWhenInUseAuthorization()
                    completion(nil)
                }
                // You can start location updates or perform other actions here
            case .denied, .restricted:
                print("Location services are denied or restricted.")
                self.locationManager.requestWhenInUseAuthorization()
                completion(nil)
                // Handle denied or restricted status
            case .notDetermined:
                print("Location services authorization not determined. Requesting...")
                self.locationManager.requestWhenInUseAuthorization()
                completion(nil)
            @unknown default:
                break
                
            }
        }
    }
    
    //MARK:- Checking location access
    func checkLocationAuthorizationStatus(completion: @escaping (CLAuthorizationStatus) -> Void) {
        
        let authorizationStatus = locationManager.authorizationStatus
        
        if authorizationStatus == .notDetermined {
            // Location services not yet determined, the user might be prompted for permission
            completion(.notDetermined)
        } else {
            // Provide the authorization status through the completion handler
            completion(authorizationStatus)
        }
    }
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if locations.last != nil {
            // Call your custom function with a completion handler
            locationManager.stopUpdatingLocation()
        }
    }
    
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error, completion: @escaping(String?) -> Void) {
        print("Location manager failed with error: \(error.localizedDescription)")
        completion(nil)
    }
    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            // Handle authorized status
            print("Location permission granted")

        case .denied, .restricted:
            // Handle denied or restricted status
            print("Location permission denied or restricted")
            locationManager.requestWhenInUseAuthorization()

        case .notDetermined:
            // Handle not determined status (e.g., ask for permission)
            print("Location permission not determined")
            locationManager.requestWhenInUseAuthorization()

        @unknown default:
            break
        }
    }
    
}

