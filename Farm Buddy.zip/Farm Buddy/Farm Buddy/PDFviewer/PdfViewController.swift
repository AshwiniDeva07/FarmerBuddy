//
//  PdfViewController.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 03/02/24.
//

import UIKit
import PDFKit

class PdfViewController: UIViewController {
    
    var pdfURL = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        DispatchQueue.main.async {
            self.displayPdf(pdfData: self.pdfURL)
        }
        
        
    }
    
    private func createPdfView(withFrame frame: CGRect) -> PDFView {
        
        let pdfView = PDFView(frame: frame)
        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pdfView.autoScales = true
        
        return pdfView
    }
    
    private func createPdfDocument(url: String) -> PDFDocument? {
        
        if let resourceUrl = URL(string: url) {
            return PDFDocument(url: resourceUrl)
        }
        
        return nil
    }
    
    private func displayPdf(pdfData: String) {
        
        let pdfView = self.createPdfView(withFrame: self.view.bounds)
        if let pdfDocument = self.createPdfDocument(url: pdfData) {
            self.view.addSubview(pdfView)
            pdfView.document = pdfDocument
        }
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
