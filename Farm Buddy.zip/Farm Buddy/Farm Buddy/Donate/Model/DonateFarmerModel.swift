//
//  DonateFarmerModel.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 03/02/24.
//

import Foundation

struct DonateFarmer: Codable {
    var data: [DonateData]?
}

// MARK: - DonateData
struct DonateData: Codable {
    var name, phoneNumber: String?
    var amount, amountProgress: Int?
    var description: String?
    var file: String?

    enum CodingKeys: String, CodingKey {
        case name
        case phoneNumber = "phone_number"
        case amount
        case amountProgress = "amount_progress"
        case description, file
    }
}
