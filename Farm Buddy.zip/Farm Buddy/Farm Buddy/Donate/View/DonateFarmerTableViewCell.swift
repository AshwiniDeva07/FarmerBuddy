//
//  DonateFarmerTableViewCell.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 03/02/24.
//

import UIKit

protocol UpdateProgressDelegate{
    func updateProgressBar()
}

class DonateFarmerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var donateView: UIView!
    @IBOutlet weak var userDetail: UILabel!
    @IBOutlet weak var descTitle: UILabel!
    @IBOutlet weak var requestedAmnt: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var descDetail: UITextView!
    @IBOutlet weak var downloadBtn: UIButton!
    @IBOutlet weak var donateBtn: UIButton!
    @IBOutlet weak var pendingAmnt: UILabel!
    
    var donateData: DonateData?
    var collectedAmnt = 0.0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setupUI()
    }
    
    func setupUI() {
        donateView.layer.cornerRadius = 8
        donateBtn.layer.cornerRadius = 4
        descDetail.isEditable = false
    }
    
    
    //MARK:- updating new data to model
    func setDonateData(donateData: DonateData?) {
        
        let progress = Double(donateData?.amountProgress ?? 0) / Double(donateData?.amount ?? 0)
        progressBar.progress = Float(progress)
        
        userDetail.text = "\(donateData?.name ?? ""), " + "\(donateData?.phoneNumber ?? "")"
        requestedAmnt.text = "Rs \(donateData?.amount ?? 0)"
        descDetail.text = "\(donateData?.description ?? "")"
        pendingAmnt.text = "Rs \(donateData?.amountProgress ?? 0)"
        
    }
    
    // Function to simulate progress update (you should replace this with your actual logic)
    func updateProgress() {
        collectedAmnt += 100.0 // Update the amount as needed
        updateUI(collectedAmnt: 0, requestedAmount: 0)
    }
    
    // Update UI elements based on the current progress
    func updateUI(collectedAmnt: Int,requestedAmount: Int) {
        let progress = collectedAmnt / requestedAmount
        progressBar.progress = Float(progress)
        pendingAmnt.text = "\(requestedAmount - collectedAmnt)"
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
