//
//  DonateFarmerViewController.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 03/02/24.
//

import UIKit
import PDFKit

class DonateFarmerViewController: UIViewController {
    
    @IBOutlet weak var donateTableView: UITableView!
    
    var donateData: DonateFarmer?
    let donateViewModel = DonateViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        donateTableView.delegate = self
        donateTableView.dataSource = self
        donateTableView.separatorStyle = .none
        donateTableView.showsVerticalScrollIndicator = false
        
        let nib = UINib(nibName: "DonateFarmerTableViewCell", bundle: nil)
        donateTableView.register(nib, forCellReuseIdentifier: "DonateFarmerTableViewCell")
        
        
        fetchCoreData()
        
        
    }
    
    //MARK:- Fetch data from core data
    func fetchCoreData(){
        if let donationData = donateViewModel.fetchDonationData() {
            if donationData.count > 0 {
                // Use donationData, which is an array of DonateData
                let donateFarmer = DonateFarmer(data: donationData)
                donateData = donateFarmer
                
                DispatchQueue.main.async {
                    self.donateTableView.reloadData()
                }
            }else{
                loadDonateData()
            }
            
        } else {
            loadDonateData()
            print("Failed to fetch donation data.")
        }
    }
    
    //MARK:- Loading donate data from core data
    func loadDonateData() {
        donateData = donateViewModel.fetchData(fileName: "Donate", fileType: "json", modelType: DonateFarmer.self)
        donateViewModel.saveToCoreData(donateFarmer: donateData ?? DonateFarmer())
        DispatchQueue.main.async {
            self.donateTableView.reloadData()
        }
        
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension DonateFarmerViewController: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return donateData?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 280
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DonateFarmerTableViewCell", for: indexPath) as? DonateFarmerTableViewCell
        
        cell?.setDonateData(donateData: donateData?.data?[indexPath.row])
        cell?.downloadBtn.addTarget(self, action: #selector(viewPDF), for: .touchUpInside)
        cell?.donateBtn.addTarget(self, action: #selector(donateBtn), for: .touchUpInside)
        cell?.donateBtn.titleLabel?.textColor = .white
        cell?.donateBtn.tag = indexPath.row
        cell?.downloadBtn.tag = indexPath.row
        
        return cell ?? UITableViewCell()
    }
    
    //MARK:- donateBtn
    @objc func donateBtn(sender: UIButton){
        let alertController = UIAlertController(title: "Enter Amount", message: nil, preferredStyle: .alert)
        
        alertController.addTextField { textField in
            textField.placeholder = "Amount"
            textField.keyboardType = .decimalPad
            textField.delegate = self
        }
        
        let okAction = UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            guard let self = self else { return }
            if let amountString = alertController.textFields?.first?.text,
               let amount = Double(amountString) {
                print("Entered Amount: \(amount)")
                let collectedAmnt = Double(donateData?.data?[sender.tag].amount ?? 0)  - Double(donateData?.data?[sender.tag].amountProgress ?? 0)
                if amount > collectedAmnt {
                    self.showInvalidInputAlert(message: "Enter amount greater than collected amount")
                }else {
                    donateViewModel.updateAmountProgress(at: sender.tag, newAmountProgress: Int(amount))
                    fetchCoreData()
                }
            } else {
                self.showInvalidInputAlert(message: "Enter valid amount")
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    func showInvalidInputAlert(message: String) {
        let alert = UIAlertController(title: "Invalid Input", message: "\(message)", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    //MARK:- viewPDF
    @objc func viewPDF(sender: UIButton){
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "PdfViewController") as? PdfViewController
        vc?.pdfURL = donateData?.data?[sender.tag].file ?? ""
        self.navigationController?.pushViewController(vc!, animated: false)
    }
    
}

extension DonateFarmerViewController : UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let currentText = textField.text else {
            return true
        }
        
        let newLength = currentText.count + string.count - range.length
        return newLength <= 10
    }
}
