//
//  DonateEntityCoreData.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 04/02/24.
//

import Foundation
import CoreData

@objc(RequestDonateEntity)
public class RequestDonateEntity: NSManagedObject {
    
}


extension RequestDonateEntity {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<RequestDonateEntity> {
        return NSFetchRequest<RequestDonateEntity>(entityName: "RequestDonateEntity")
    }
    
    @NSManaged public var name: String?
    @NSManaged public var phoneNumber: String?
    @NSManaged public var amount: Int32
    @NSManaged public var amountProgress: Int32
    @NSManaged public var requestdescription: String?
    @NSManaged public var file: String?
    
}
