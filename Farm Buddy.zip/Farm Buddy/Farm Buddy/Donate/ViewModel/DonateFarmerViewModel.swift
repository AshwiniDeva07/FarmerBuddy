//
//  DonateFarmerViewModel.swift
//  Farm Buddy
//
//  Created by ASHWINI DS on 03/02/24.
//

import Foundation
import UIKit
import CoreData

class DonateViewModel{
    
    //MARK:- Fetch data from core data
    func fetchData<T: Decodable>(fileName: String, fileType: String, modelType: T.Type) -> T? {
        // Specify the file path where your JSON file is located
        guard let filePath = Bundle.main.path(forResource: fileName, ofType: fileType) else {
            print("Error finding JSON file")
            return nil
        }
        do {
            // Load JSON data from the file
            let jsonData = try Data(contentsOf: URL(fileURLWithPath: filePath))
            // Decode JSON data into the specified model type
            let decodedData = try JSONDecoder().decode(modelType, from: jsonData)
            return decodedData
        } catch {
            print("Error decoding JSON data: \(error.localizedDescription)")
            return nil
        }
    }
    
    //MARK:- Save data to core data
    func saveToCoreData(donateFarmer: DonateFarmer) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        // Loop through the data array and save each item
        donateFarmer.data?.forEach { donateData in
            let entity = NSEntityDescription.entity(forEntityName: "RequestDonateEntity", in: managedContext)!
            let donateEntity = NSManagedObject(entity: entity, insertInto: managedContext) as! RequestDonateEntity
            
            // Map your DonateData properties to the Core Data entity
            donateEntity.name = donateData.name
            donateEntity.phoneNumber = donateData.phoneNumber
            donateEntity.amount = Int32(truncating: NSNumber(value: donateData.amount ?? 0))
            donateEntity.amountProgress = Int32(truncating: NSNumber(value: donateData.amountProgress ?? 0))
            donateEntity.requestdescription = donateData.description
            donateEntity.file = donateData.file
            
            // Save the managed object context
            do {
                try managedContext.save()
            } catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
        }
    }
    
    //MARK:- Fetching donation data from core data
    func fetchDonationData() -> [DonateData]? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return nil
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<RequestDonateEntity>(entityName: "RequestDonateEntity")
        
        do {
            let results = try managedContext.fetch(fetchRequest)
            return mapToDonateDataArray(from: results)
        } catch let error as NSError {
            print("Fetch error: \(error), \(error.userInfo)")
            return nil
        }
    }
    
    func fetchDonationEntity() -> [RequestDonateEntity]? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return nil
        }
        let fetchRequest = NSFetchRequest<RequestDonateEntity>(entityName: "RequestDonateEntity")
        let managedContext = appDelegate.persistentContainer.viewContext

        do {
            let results = try managedContext.fetch(fetchRequest)
            return results
        } catch let error as NSError {
            print("Fetch error: \(error), \(error.userInfo)")
            return nil
        }
    }
    
    //MARK:- Mapping data to Donate
    private func mapToDonateDataArray(from entities: [RequestDonateEntity]) -> [DonateData] {
        return entities.map { entity in
            DonateData(
                name: entity.name,
                phoneNumber: entity.phoneNumber,
                amount: Int(entity.amount),
                amountProgress: Int(entity.amountProgress),
                description: entity.requestdescription,
                file: entity.file
            )
        }
    }
    
    //MARK:- Updating new amount to core data
    func updateAmountProgress(at index: Int, newAmountProgress: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
       
        
        if let donationData = fetchDonationEntity(), index < donationData.count {
            var entityToUpdate = donationData[index]
            var additionalAmount = Int32(newAmountProgress) + entityToUpdate.amountProgress
            entityToUpdate.amountProgress = Int32(additionalAmount)
            
            do {
                try managedContext.save()
                print("Updated\(entityToUpdate.amountProgress) \(Int32()) successfully.")
                
                print("Updated amountProgress for index \(index) successfully.")
            } catch let error as NSError {
                print("Update error: \(error), \(error.userInfo)")
            }
        } else {
            print("Invalid index or failed to fetch donation data.")
        }
    }
    
    
}
